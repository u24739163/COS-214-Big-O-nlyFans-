
#include "Users.h"
#include "Command.h"

void Users::send(string message, ChatRoom* room) {
    addCommand(new SendMessageCommand(room, this, message));
    addCommand(new LogMessageCommand(room, this, message));
    executeAll();
}

void Users::receive(string message, Users fromUser, ChatRoom* room) {
    cout << name << " received a message from " << fromUser.getName() << " in chat room: " << message << endl;
}

void Users::addCommand(Command* command) {
    commandQueue.push_back(command);
}

void Users::executeAll() {
    for (Command* command : commandQueue) {
        command->execute();
        delete command; 
    }
    commandQueue.clear();
}

bool Users::operator!=(const Users& other) const {
    return name != other.getName();
}

bool Users::operator==(const Users& other) const {
    return name == other.getName();
}