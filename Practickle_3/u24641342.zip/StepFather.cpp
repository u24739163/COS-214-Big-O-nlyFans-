// StepFather.cpp - Template implementations are in header file
// This file is intentionally empty as template class methods 
// must be defined in the header file (StepFather.h)